    updateStrategy: Never ，关闭自动更新
    antiAffinityTopologyKey: "kubernetes.io/hostname"，此参数将禁止pods运行在同一台主机上