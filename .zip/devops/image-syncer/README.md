## 下载地址
```
https://github.com/AliyunContainerService/image-syncer/releases
https://hub.fastgit.org/AliyunContainerService/image-syncer/releases
```
## 使用方法
```
nohup image-syncer --auth=./auth.yaml --images=./images.yaml &
```
根据不同的镜像，我会制作不同的images.yaml，例如images-k8s.yaml 