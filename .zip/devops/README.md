# 存储devops开发脚本

功能：

```
ceph-yaml :  存储有关使用rook-ceph作为存储的yaml脚本,sc名称为 rook-ceph-block
ceph-helm :  存储有关使用rook-ceph作为存储的yaml脚本,sc名称为 rook-ceph-block

nfs-yaml :  存储有关使用nfs作为存储的yaml脚本,sc名称为 nfs-client
nfs-helm :  存储有关使用nfs作为存储的yaml脚本,sc名称为 nfs-client
```
