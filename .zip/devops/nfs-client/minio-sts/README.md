If deployed in default namespaces , you can use default-ns.yaml.
If deployed in minio namespaces , you can use minio-ns.yaml.