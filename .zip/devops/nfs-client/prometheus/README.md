说明

1-kube-prometheus-manifests-setup 和 2-kube-prometheus-manifests 对应的是官方的kube-prometheus的yaml文件

应该先安装manifests中的setup，后安装manifests

3-patch-yaml 是自己的改编文件，旨在修改官方配置

