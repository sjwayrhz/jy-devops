app-web-dev-withconfigmap.yaml
添加app-web对于configmap的支持

app-web-dev-withpv.yaml
添加app-web对于pv的支持


app-web-dev-withprobe.yaml
添加app-web对于livenessProbe和readinessProbe的支持


web-dev-noenv.yaml
取消`app-`

office-vue-secret.yaml
通过secret拉镜像