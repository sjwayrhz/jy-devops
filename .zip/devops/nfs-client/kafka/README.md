# kafka-kubernetes

This project is a simple representation of how you can deploy kafka queue to kubernetes cluster with an essentil components
