#!/usr/bin/env groovy
package org.devops

class globalVars {
  static String foo = "bar"
}