def foo() {
  echo "Hello foo from vars/multiMethod.groovy"
}
def bar() {
  echo "Hello bar from vars/multiMethod.groovy"
}