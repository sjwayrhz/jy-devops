#!/usr/bin/env groovy

def callMap(){
  def map = [
    "demo-spring-a": "hwy-1",
    "demo-spring-b": "hwy-2"
  ]
}
  

