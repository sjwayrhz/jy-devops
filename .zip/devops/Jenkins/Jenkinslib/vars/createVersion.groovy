#!/usr/bin/env groovy

def call() {
  return new Date().format('yyyyMMddHHmm')
}
