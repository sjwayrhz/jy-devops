#!/usr/bin/env groovy

def call(String name) {
  echo "Hello, ${name}."
}

